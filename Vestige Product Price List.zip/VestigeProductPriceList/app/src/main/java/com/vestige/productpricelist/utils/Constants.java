package com.vestige.productpricelist.utils;

public class Constants {
    public static String SHARED_PRE_NAME = "VPPL";
}
