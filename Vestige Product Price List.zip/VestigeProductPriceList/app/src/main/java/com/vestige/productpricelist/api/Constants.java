package com.vestige.productpricelist.api;

public class Constants {
   public static String BASE_URL = "http://phpstack-961053-3453806.cloudwaysapps.com/";
   public static String API_KEY = "SasOPbuIyiYzqMFucgsJ";

}
